if [ "$(id -u)" != "0" ]; then
	echo "你没给root权限"
	exit 1
fi
#
get_prop() {
conf="/data/adb/swap_controller/"
  cat $conf/swap.conf | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

function zram_size() {

# 定义一个函数来获取zram_size的值
# 定义一个函数来设置zram_size的值
set_zram_size() {
    sed -i "s/^zram_size=.*/zram_size=$1/" /data/adb/swap_controller/swap.conf
}
# 获取并输出当前的zram_size值
zram_size=$(get_prop zram_size)
echo "当前的zram_size值：$zram_size zram请不要设置的超过内存 否则将会出现不必要的卡顿 耗电等情况"
# 从用户那里获取一个新的zram_size值
echo -n "请输入一个新的zram_size值：" && read new_zram_size
# 设置并输出新的zram_size值
set_zram_size $new_zram_size
echo "新的zram_size值已设置为：$new_zram_size"
sleep 1.25
    caidan
}
function zrampiness(){
# 定义一个函数来获取当前的zram积极性
get_zrampiness() {
cat /data/adb/swap_controller/swap.conf | grep -v '^#' | grep "^swappiness" | cut -f2 -d '='
}

# 定义一个函数来设置新的zram积极性
set_zrampiness() {
    sed -i "s/^swappiness=.*/swappiness=$1/" /data/adb/swap_controller/swap.conf
}
# 定义一个函数获取当前支持设置最大的zram积极性
fuck_zrampiness() {
cat /data/adb/swap_controller/swap.conf | grep -v '^#' | grep "^zrampiness" | cut -f2 -d '='
}
echo "当前支持设置的zram积极性为：$fuck_zrampiness"
# 获取并输出当前的zram积极性
zrampiness=$(get_zrampiness)
echo "当前zram积极性为：$zrampiness 推荐设置165 设置太高会导致耗电高 发热问题"

# 从用户那里获取一个新的zram积极性
echo -n "请输入要设置的zram积极性的值：" && read new_zrampiness

# 设置并输出新的zram积极性
set_zrampiness $new_zrampiness
echo "新的zram积极性已设置为：$new_zrampiness"
sleep 1.25
caidan
}
function zram_comp_algorithm(){
# 定义一个函数来获取当前支持的算法
fuck_zram_comp_algorithm=$(cat /data/adb/swap_controller/swap.conf | grep -v '^#' | grep "^zram_comp_algorithm" | cut -f2 -d '=')

# 定义一个函数来获取当前的算法
get_zram_comp_algorithm() {
cat /data/adb/swap_controller/swap.conf | grep -v '^#' | grep "^comp_algorithm" | cut -f2 -d '='
}

# 定义一个函数来设置新的zram算法
set_zram_comp_algorithm() {
    sed -i "s/^comp_algorithm=.*/comp_algorithm=$1/" /data/adb/swap_controller/swap.conf
}

# 获取并输出当前的zram算法
echo "当前支持的zram算法：$fuck_zram_comp_algorithm"
zram_comp_algorithm=$(get_zram_comp_algorithm)
echo "当前zram算法为：$zram_comp_algorithm 如果你在乎流畅请使用lz4 如果想让你的zram压缩更强请使用zstd"

# 从用户那里获取一个新的zram算法
echo -n "请输入要设置的zram算法：" && read new_zram_comp_algorithm

# 设置并输出新的zram算法
set_zram_comp_algorithm $new_zram_comp_algorithm
echo "新的zram算法已设置为：$new_zram_comp_algorithm"
sleep 1.25
caidan
}

function caidan() {
	clear
	echo "Loading……"
	sleep 0.3
	clear
# 获取总内存
mem_total=$(cat /proc/meminfo | grep "MemTotal" | awk '{print $2}')
mem_total_gb=$(echo "scale=2;$mem_total/1024/1024" | bc)
# 获取程序可用内存
mem_available=$(cat /proc/meminfo | grep "MemAvailable" | awk '{print $2}')
mem_available_gb=$(echo "scale=2;$mem_available/1024/1024" | bc)
# 计算可用内存百分比
mem_percent=$(echo "scale=2;$mem_available/$mem_total*100" | bc)
# 获取zram最大积极性
getAndroid_version=$(getprop ro.build.version.release)
zrampiness=$(cat /data/adb/swap_controller/swap.conf | grep -v '^#' | grep "^zrampiness" | cut -f2 -d '=')
echo -e "===[A0后台优化控制面板 BY:MoWei]==="
echo -e "======系统信息===="
echo -e "安卓版本:$getAndroid_version"
echo -e "\e[46m 内存状况 \e[0m"
echo -e "\e[41m 总内存: ${mem_total_gb}Gb \e[0m"
echo -e "\e[41m 可用内存百分比: ${mem_available_gb}Gb (${mem_percent}%) \e[0m"
echo -e "\e[41m ZRAM最大积极性： ${zrampiness} \e[0m"
	echo "————————————————"
	echo "1.调整ZRAM大小"
	echo "2.调整ZRAM积极性"
	echo "3.调整ZRAM算法"
	echo "4.开启乖巧进程"
	echo "5.开启休眠进程"
	echo "6.关闭乖巧进程"
	echo "7.关闭休眠进程"
	echo "8.开启详细日志"
	echo "9.关闭详细日志"
	echo "10.开启兼容模式"
	echo "11.关闭兼容模式""
	echo "12.退出"
	echo "————————————————"
	echo "键盘输入以上数字选择 请按右下角lm呼出键盘
修改配置后请重启手机生效"
echo "--------功能介绍---------" 
echo "功能1.乖巧进程" 
echo "功能介绍:当应用切换三次时 自动KILL配置文件中的线程 达到节省内存占用的作用" 
echo "功能2.休眠进程" 
echo "功能介绍:当应用切换至后台时 使用standby进行限制 达到省电的作用" 
echo "功能3.详细日志" 
echo "功能介绍:当开启乖巧进程或休眠进程时输出日志 可以辅助配置文件的开发者进行开发" 
echo "功能4.兼容模式"
echo "功能介绍:开关Hook LMKD 当开启时就会调用Hook LMKD 关闭时使用lmkd_adj函数"
echo "开启兼容模式 可以防止某些手机进入软重启 例如:魅族 OPPO等"
echo "--------功能介绍---------" 

	echo -n "输入:" && read setting
	case $setting in
	"1")
		zram_size
		;;
	"2")
		zrampiness
		;;
	"3")
		zram_comp_algorithm
		;;
	"4")
		echo "true" > /sdcard/Android/MW_A0/乖巧进程.conf
		;;
	"5")
		echo "true" > /sdcard/Android/MW_A0/休眠进程.conf
		;;
	"6")
		rm -rf /sdcard/Android/MW_A0/乖巧进程.conf
		;;
	"7")
		rm -rf /sdcard/Android/MW_A0/休眠进程.conf
		;;	
	"8")
		echo "true" > /sdcard/Android/MW_A0/详细日志.conf
		;;
	"9")
		rm -rf /sdcard/Android/MW_A0/详细日志.conf
		;;	
	"10")
		echo "true" > /sdcard/Android/MW_A0/兼容模式.conf
		;;	
    "11")
		rm -rf /sdcard/Android/MW_A0/兼容模式.conf
		;;	
    "12")
		exit
		;;	
	*)
		echo "参数错误"
		caidan
		;;
	esac
}
caidan
