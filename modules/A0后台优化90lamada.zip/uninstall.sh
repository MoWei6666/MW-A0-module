echo "开始卸载A0内存保活"
sleep 2
rm -rf /data/swapfile*
rm -rf /data/swap_recreate
rm -rf /data/swap_config.conf
rm -rf /data/adb/swap_controller
rm -rf /data/adb/modules/MW_A0
rm -rf /data/adb/modules_update/MW_A0
rm -rf /data/adb/modules/scene_swap_controller
rm -rf /sdcard/Android/MW_A0
kill -19 MW_memory
echo "卸载完成"