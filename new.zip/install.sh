MODDIR=${0%/*}
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE=""
alias settings="/system/bin/settings"
alias device_config="/system/bin/device_config"

rm -rf /data/adb/modules/scene_swap_controller/
rm -rf /data/adb/ksu/modules/scene_swap_controller/
rm -rf /data/adb/ksu/modules/swap_controller/
rm -rf /data/adb/modules/zram_baohuo
rm -rf /data/adb/modules/new_zram_baohuo
rm -rf /data/adb/modules/new_zrambaohuo
rm -rf /data/adb/modules/MW_A0
rm -rf /data/adb/modules/zram_huanchen
rm -rf /data/adb/modules/RamBooster
rm -rf /sdcard/Android/MW_A0
rm -rf /data/adb/modules/NEW_MW_A0
rm -rf /data/adb/modules/Hc_memory
# 虚进程的调整 
settings put global settings_enable_monitor_phantom_procs false
device_config set_sync_disabled_for_tests persistent
device_config put activity_manager max_cached_processes 2147483647
device_config put activity_manager max_phantom_processes 2147483647
settings put global activity_manager_constants max_cached_processes=2147483647
settings put global activity_manager_constants max_phantom_processes=2147483647

update_system_prop() {
  local prop="$1"
  local value="$2"
  sed -i "s/^$prop=.*/$prop=$value/" /data/adb/swap_controller/keep.conf
}
sponsor() {
    echo "#################################
 - 按音量键＋: 赞助人机作者
 - 按音量键－: 人机也配爷赞助
#################################"
    while true; do
        choose="$(getevent -qlc 1 | awk '{ print $3 }')"
        case "${choose}" in
            KEY_VOLUMEUP)
                echo "感谢支持"
                am start -a android.intent.action.VIEW -d https://afdian.net/a/MoWei_2077 >/dev/null &
                break
                ;;
            KEY_VOLUMEDOWN)
                break
                ;;
            *)
                continue
                ;;
        esac
    done
}
A0="/data/adb/modules_update/MW_A0"
# 赞助支持
if [[ ! -f $A0/.sponsor ]]; then
    sponsor
    echo 'yes' > $A0/.sponsor
fi
print_modname() {

  # 获取模块版本号
  swap_version="$TMPDIR/module.prop"
  function get_prop() {
    cat $swap_version | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
  }
  module=$(get_prop version)

  # 输出信息
  echo " ****************************************"
  echo "  A0后台内存保活安装成功！"
  echo "  模块版本：$module"
  echo "  安装时间：$ins"
  echo "  配置文件位置：看模块介绍"
  output=$(pm list packages com.venus.backgroundopt)
if [ ${#output} -gt 2 ]; then
    echo "- !!! ⚠️检测到 [后台优化] (安好不打扰), 请到 LSPosed 手动取消勾选"
fi
output=$(pm list packages com.MW_Memory_rescue.plan)
if [ ${#output} -gt 2 ]; then
    echo "- !!! ⚠️检测到 [A0内存拯救计划] (魔威), 请到 LSPosed 手动取消勾选"
fi
output=$(pm list packages com.hchai.rescueplan)
if [ ${#output} -gt 2 ]; then
    echo "- !!! ⚠️检测到 [A1-内存管理-附加] (hchai), 请到 LSPosed 手动取消勾选"
fi
if [ -e "/data/adb/modules/Hc_tombstone" ]; then
    echo "- !!! ⚠️已禁用 [保后台能力增强](焕晨)"
    touch /data/adb/modules/Hc_tombstone/disable
fi

  # 标记scenefu附加模块
rm_
  sleep 0.5
             echo "即将开始安装附加模块"
        echo "  #################################
 - 按音量键＋: 安装附加模块 
 - 按音量键－: 不安装附加模块
 #################################"
      key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.35
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
	ui_print "- 正在释放文件"
	unzip -o "$ZIPFILE" 'common/*' -d $MODPATH >&2
	unzip -o "$ZIPFILE" 'app/*' -d $MODPATH >&2
	name=$(pm list packages | grep -w package:com.venus.backgroundopt)
	A0="package:com.venus.backgroundopt"
	if [[ $name == $A0 ]]
	then
		ui_print "- 安装脚本出现异常"
	else
		ui_print "- 附加模块未安装"
		unzip -o "$ZIPFILE" 'app.apk' -d /data/local/tmp/ >&2
		#以下安装APK代码来由搞机助手
		export File='/data/local/tmp/app.apk'
		export Delete_APK='1'
		
			ui_print "$@" 1>&2
		
		IFS=$'\n'
		suffix=${File##*.}
		name=`basename "$File"`
		[[ $1 = -s ]] && installer=" -i $installer " || installer=" "
		ui_print "- 正在安装附加模块"
		if [[ ! -f $File ]]; then
			abort "- 文件不存在"
		else
			unzip -l "$File" &>/dev/null
			[[ $? -ne 0 ]] && abort "- $name 不是压缩文件"
		fi
		if [[ $suffix = apk ]]; then
			size=`ls -l "$File" | awk '{print $5}'`
			a="cat \""$File"\" | pm install -r -d -S "$size""$installer" 1> /dev/null"
			eval $a
			result=$?
			if [[ $result = 0 ]]; then
				ui_print "- 附加模块 安装成功"
				[[ $Delete_APK = 1 ]] && rm -f "$File"

			else
				abort -e "- 附加模块 安装失败"
			fi
		fi
	fi
    ui_print "* 安装成功"
        ;;
        *)
            ui_print "已成功取消安装"
    esac
  echo " ****************************************"
}
  
# 检测内核支持的压缩方式
check_result1=`cat /sys/block/zram0/comp_algorithm | grep lz4`
check_result2=`cat /sys/block/zram0/comp_algorithm | grep zstd`
check_result3=`cat /sys/block/zram0/comp_algorithm | grep lzo-rle`
if [[ "$check_result1" != "" ]]; then
  comp_algorithm=zstd
elif [[ "$check_result2" != "" ]]; then
  comp_algorithm=lz4
elif [[ "$check_result3" != "" ]]; then
  comp_algorithm=lzo-rle
else
  comp_algorithm=lzo
fi

ins=$(date "+%m月%d日_%H时%M分")

# 创建配置参数
# 不添加开启 开启将会消耗闪存寿命
swap=false
swap_size=0
swap_priority=-2
swap_use_loop=false
zram=true
zram_size=8192
# 如果你的内核支持100-200 则默认为150 
# 因为swappiness设置太高就会在游戏等需要CPU的高负债工作中与swappiness抢CPU
swappiness=100

# swap积极性
sp=$(sysctl -w vm.swappiness=200)
if [ "$sp" == "vm.swappiness = 200" ]; then
#目的省电
swappiness=150
sp_w="200"
else
sp_w="100"
fi

# 支持的压缩方式
ca1=`cat /sys/block/zram0/comp_algorithm`
ca2=$(echo "${ca1// /，}")
ca3=$(echo "${ca2//[/}")
ca4=$(echo "${ca3//]/}")
ca5=$(echo "${ca4%，*}")

# 以下是老BUG了 我不想修了 如果动手能力强 请自行修复
MemTotalStr=`cat /proc/meminfo | grep MemTotal`
MemTotalKB=${MemTotalStr:16:8}
if [[ $MemTotalKB -gt 12582912 ]]; then
  zram_size=15360
else
  zram_size=12288
  fi
# > 8G
if [[ $MemTotalKB -gt 8388608 ]]; then
  zram_size=10240
else
 zram_size=8192
  fi
# > 6G
if [[ $MemTotalKB -gt 6291456 ]]; then
  zram_size=8192
# > 4GB
elif [[ $MemTotalKB -gt 4194304 ]]; then
  zram_size=6144
else
  zram_size=2048
fi
on_install() {

# 开始安装
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
[[ ! -d /data/adb/swap_controller ]] && mkdir -p /data/adb/swap_controller

# 读取参数
if [[ -f "/data/adb/swap_controller/keep.conf" ]]; then
function get_prop() {
  cat /data/adb/swap_controller/keep.conf | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}
current_swap=$(get_prop swap)
current_swap_size=$(get_prop swap_size)
current_swap_priority=$(get_prop swap_priority)
current_swap_use_loop=$(get_prop swap_use_loop)
current_zram=$(get_prop zram)
current_zram_size=$(get_prop zram_size)
current_comp_algorithm=$(get_prop comp_algorithm)
current_swappiness=$(get_prop swappiness)
current_writeback_size=$(get_prop writeback_size)
current_writeback_sleep=$(get_prop writeback_sleep)
current_writeback_number=$(get_prop writeback_number)
current_writeback_writeback=$(get_prop writeback_writeback)
# 应用参数
if [[ "$current_swap" != "" ]]; then
swap="$current_swap"
update_system_prop swap $swap
fi
if [[ "$current_swap_size" != "" ]]; then
swap_size="$current_swap_size"
update_system_prop swap_size $swap_size
fi
if [[ "$current_swap_priority" != "" ]]; then
swap_priority="$current_swap_priority"
update_system_prop swap_priority $swap_priority
fi
if [[ "$current_swap_use_loop" != "" ]]; then
swap_use_loop="$current_swap_use_loop"
update_system_prop swap_use_loop $swap_use_loop
fi
if [[ "$current_zram" != "" ]]; then
zram="$current_zram"
update_system_prop zram $zram
fi
if [[ "$current_zram_size" != "" ]]; then
zram_size="$current_zram_size"
update_system_prop zram_size $zram_size
fi
if [[ "$current_comp_algorithm" != "" ]]; then
comp_algorithm="$current_comp_algorithm"
update_system_prop comp_algorithm $comp_algorithm
fi
if [[ "$current_swappiness" != "" ]]; then
swappiness="$current_swappiness"
update_system_prop swappiness $swappiness
fi
if [[ "$current_writeback_size" != "" ]]; then
writeback_size="$current_writeback_size"
update_system_prop writeback_size $writeback_size
fi
if [[ "$current_writeback_sleep" != "" ]]; then
writeback_sleep="$current_writeback_sleep"
update_system_prop writeback_sleep $writeback_sleep
fi
if [[ "$current_writeback_number" != "" ]]; then
writeback_number="$current_writeback_number"
update_system_prop writeback_number $writeback_number
fi
if [[ "$current_writeback_writeback" != "" ]]; then
writeback_writeback="$current_writeback_writeback"
update_system_prop writeback_writeback $writeback_writeback
fi
fi


echo "✔ 模块版本：$module
✔ 安装时间：$ins
✔ 除特殊说明外，true为开启，false为关闭
✔ 提示：正常情况下无需修改本页面的任何参数
✔ 注意：修改参数后，需要重启手机后才能生效
---------------------------------------------------------------------------
# 配置swapfile
swap=$swap

# swap大小 [MB]
# 修改后需手动删除/data/swapfile文件
swap_size=$swap_size

# swapfile使用顺序
# [0] 与zram同时使用
# [-2] 用完zram后再使用
# [5] 优先于zram使用
swap_priority=$swap_priority

# swapfile挂载为回环设备
swap_use_loop=$swap_use_loop
---------------------------------------------------------------------------
# 配置zram
zram=$zram

# zram大小 [MB]
zram_size=$zram_size

# zram压缩算法 (comp_algorithm)
zram_comp_algorithm=当前内核支持的压缩方式有：[$ca5]
comp_algorithm=$comp_algorithm

# swap积极性 [%] (swappiness)
zrampiness=当前内核支持设置的范围是：[0-${sp_w}]
swappiness=$swappiness

" > /data/adb/swap_controller/swap.conf
echo "模块安装后请勿立马退出 等待1-2秒复制文件"
sleep 1
mkdir /sdcard/Android/MW_A0
chmod 777 /sdcard/Android/MW_A0
cp -f ${TMPDIR}/keep.conf /data/adb/swap_controller
cp -f ${TMPDIR}/面板.sh /sdcard/Android/MW_A0
cp -f ${TMPDIR}/配置文件.conf /sdcard/Android/MW_A0
chmod 777 /data/adb/modules_update/scene_swap_controller/*
}